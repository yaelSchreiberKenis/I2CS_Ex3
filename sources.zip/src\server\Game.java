package server;

import java.awt.Color;
import java.util.List;
import java.util.Random;

/**
 * Main game server implementation
 * Manages game state, logic, and provides interface for algorithms
 */
public class Game implements PacmanGame {
    
    // Direction constants (for Ex3Algo compatibility)
    public static final int UP = 0;
    public static final int LEFT = 1;
    public static final int DOWN = 2;
    public static final int RIGHT = 3;
    public static final int ERR = -1;
    
    /**
     * Static utility method to convert Color to int (for Ex3Algo)
     */
    public static int getIntColor(Color color, int code) {
        if (color.equals(Color.BLUE)) return GameState.WALL;
        if (color.equals(Color.PINK)) return GameState.DOT;
        if (color.equals(Color.GREEN)) return GameState.POWER_PELLET;
        return GameState.EMPTY;
    }
    private GameState gameState;
    private Random random;
    private AudioManager audioManager; // Audio system for music and sound effects
    private int lastPacmanDirection = RIGHT; // Track last direction for Pacman rotation
    private int dt; // Delay time between moves in milliseconds
    private int moveCount = 0; // Track number of moves (for delaying ghost movement)
    private int scenario = 0; // Scenario (0-4) for smart ghost movement probability
    private boolean gameEndSoundPlayed = false; // Track if end sound was played
    private static final int DOT_SCORE = 10;
    private static final int POWER_PELLET_SCORE = 50;
    private static final int GHOST_SCORE = 200;
    private static final int GHOST_START_DELAY = 50; // Ghosts don't move for first 50 moves
    private static final double GHOST_MOVE_PROBABILITY = 0.3; // Ghosts move 30% of the time (slower)
    private static final int GHOST_START_X = 11; // Ghost starting X position
    private static final int GHOST_START_Y = 11; // Ghost starting Y position

    public Game() {
        this.audioManager = new AudioManager();
    }

    public void init(int scenario, String id, boolean cyclic, long seed, 
                     double resolution, int dt, int unused) {
        this.gameState = new GameState(cyclic, dt);
        this.random = new Random(seed);
        this.dt = dt;
        this.moveCount = 0; // Reset move counter
        this.scenario = Math.max(0, Math.min(4, scenario)); // Store scenario (0-4)
        this.gameEndSoundPlayed = false;
        initializeGame();
        initializeGUI();
        // Start in PAUSED state - wait for space key to start
        gameState.setStatus(PacmanGame.PAUSED);
        waitForSpaceKey();
        play();
    }
    
    /**
     * Wait for space key press before starting the game
     */
    private void waitForSpaceKey() {
        // Render initial state
        render();
        StdDraw.show();
        
        // Wait for space key
        while (true) {
            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();
                if (key == ' ') {
                    break; // Space pressed, start the game
                }
            }
            StdDraw.pause(50); // Small delay to avoid busy waiting
        }
    }
    
    private void initializeGame() {
        // Set initial Pacman position
        gameState.setPacmanPosition(14, 11);
        
        // Always add exactly 4 ghosts
        for (int i = 0; i < 4; i++) {
            addGhost(GHOST_START_X, GHOST_START_Y);
        }
    }
    
    private void addGhost(int x, int y) {
        if (gameState == null) return;
        GhostImpl ghost = new GhostImpl(x, y, gameState);
        gameState.addGhost(ghost);
    }
    
    @Override
    public int[][] getGame(int code) {
        if (gameState == null) return new int[0][0];
        return gameState.getBoard();
    }
    
    @Override
    public String getPos(int code) {
        if (code == 0) { // Pacman
            return gameState.getPacmanX() + "," + gameState.getPacmanY();
        }
        return "0,0";
    }
    
    @Override
    public GhostCL[] getGhosts(int code) {
        if (gameState == null) return new GhostCL[0];
        List<GhostImpl> ghosts = gameState.getGhosts();
        return ghosts.toArray(new GhostCL[ghosts.size()]);
    }
    
    
    @Override
    public int getStatus() {
        if (gameState == null) return PacmanGame.NOT_STARTED;
        return gameState.getStatus();
    }
    
    @Override
    public void move(int dir) {
        if (gameState == null) return;
        if (gameState.getStatus() != PacmanGame.RUNNING) {
            return;
        }
        
        int dx = 0, dy = 0;
        switch (dir) {
            case UP:
                dy = 1; // Up increases y (small y's are down)
                break;
            case DOWN:
                dy = -1; // Down decreases y
                break;
            case LEFT:
                dx = -1;
                break;
            case RIGHT:
                dx = 1;
                break;
            default:
                return;
        }
        
        int newX = gameState.getPacmanX() + dx;
        int newY = gameState.getPacmanY() + dy;
        
        // Handle cyclic wrapping
        newX = gameState.wrapX(newX);
        newY = gameState.wrapY(newY);
        
        // Check that the position is valid AND not a wall (prevents moving into walls)
        if (gameState.isValidPosition(newX, newY) && gameState.getCell(newX, newY) != GameState.WALL) {
            gameState.setPacmanPosition(newX, newY);
            lastPacmanDirection = dir; // Update direction
            
            // Check what's at the new position
            int cell = gameState.getCell(newX, newY);
            if (cell == GameState.DOT) {
                gameState.setCell(newX, newY, GameState.EMPTY);
                gameState.addScore(DOT_SCORE);
                audioManager.playDotEaten();
            } else if (cell == GameState.POWER_PELLET) {
                gameState.setCell(newX, newY, GameState.EMPTY);
                gameState.addScore(POWER_PELLET_SCORE);
                audioManager.playPowerPellet();
                // Make all ghosts vulnerable for 100 moves
                for (GhostImpl ghost : gameState.getGhosts()) {
                    ghost.setVulnerableTime(100);
                }
            }
        }
        
        // Always check collision after Pacman's move (even if Pacman didn't move)
        checkGhostCollisions();
        
        moveCount++; // Increment move counter
        updateGame();
        
        // Check collision again after ghosts move (ghosts might have moved into Pacman)
        checkGhostCollisions();
        render();
        // Slow the game using dt
        StdDraw.pause(dt);
    }
    
    private void checkGhostCollisions() {
        int pacX = gameState.getPacmanX();
        int pacY = gameState.getPacmanY();
        
        for (GhostImpl ghost : gameState.getGhosts()) {
            if (ghost.getX() == pacX && ghost.getY() == pacY) {
                if (ghost.isVulnerable()) {
                    // Eat ghost - move it back to starting position
                    ghost.setPosition(GHOST_START_X, GHOST_START_Y);
                    gameState.addScore(GHOST_SCORE);
                    // Play ghost eaten sound effect
                    audioManager.playGhostEaten();
                } else {
                    // Collision with non-vulnerable ghost - game over
                    gameState.setStatus(PacmanGame.DONE);
                    if (!gameEndSoundPlayed) {
                        audioManager.playGameOver();
                        gameEndSoundPlayed = true;
                    }
                }
            }
        }
    }
    
    private void updateGame() {
        // Update shared ghost vulnerable time (synchronized for all ghosts) - move-based (1.0 per move)
        gameState.decreaseSharedVulnerableTime(); // Decrement by 1 move per update

        moveGhosts();
        
        // Check win condition
        if (allDotsEaten()) {
            gameState.setStatus(PacmanGame.DONE);
            if (!gameEndSoundPlayed) {
                audioManager.playWin();
                gameEndSoundPlayed = true;
            }
        }
    }
    
    private void moveGhosts() {
        // Don't move ghosts for the first GHOST_START_DELAY moves
        if (moveCount < GHOST_START_DELAY) {
            return;
        }
        
        int pacX = gameState.getPacmanX();
        int pacY = gameState.getPacmanY();
        
        // Create GameMap for pathfinding
        GameMap map = createGameMap();
        
        // Smart movement probability based on scenario level (0-4)
        // Level 0: 5%, Level 1: 15%, Level 2: 25%, Level 3: 35%, Level 4: 45%
        double smartProbability = 0.05 + (scenario * 0.1);
        
        List<GhostImpl> ghosts = gameState.getGhosts();
        for (GhostImpl ghost : ghosts) {
            int ghostX = ghost.getX();
            int ghostY = ghost.getY();
            
            // All ghosts can be smart, but with probability based on level
            if (random.nextDouble() < smartProbability && map != null) {
                // Smart move: use GameMap to find shortest path to Pacman
                Pixel2D ghostPos = new Index2D(ghostX, ghostY);
                Pixel2D pacmanPos = new Index2D(pacX, pacY);
                Pixel2D[] path = map.shortestPath(ghostPos, pacmanPos, GameState.WALL);
                
                if (path != null && path.length > 1) {
                    int newX = path[1].getX();
                    int newY = path[1].getY();
                    if (gameState.isValidPosition(newX, newY) && 
                        gameState.getCell(newX, newY) != GameState.WALL) {
                        ghost.setPosition(newX, newY);
                        continue;
                    }
                }
            }
            
            // Random move (when not being smart or smart move failed)
            if (random.nextDouble() < GHOST_MOVE_PROBABILITY) {
                int dir = random.nextInt(4);
                int dx = 0, dy = 0;
                switch (dir) {
                    case 0: dy = 1; break;  // UP
                    case 1: dy = -1; break; // DOWN
                    case 2: dx = -1; break; // LEFT
                    case 3: dx = 1; break;  // RIGHT
                }
                
                int newX = gameState.wrapX(ghostX + dx);
                int newY = gameState.wrapY(ghostY + dy);
                
                if (gameState.isValidPosition(newX, newY) && 
                    gameState.getCell(newX, newY) != GameState.WALL) {
                    ghost.setPosition(newX, newY);
                }
            }
        }
    }
    
    /**
     * Creates a GameMap from the current game board for pathfinding.
     */
    private GameMap createGameMap() {
        int[][] board = gameState.getBoard();
        // Transpose board for GameMap: board[x][y] -> transposed[y][x]
        int width = board.length;
        int height = board[0].length;
        int[][] transposed = new int[height][width];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                transposed[y][x] = board[x][y];
            }
        }
        GameMap map = new GameMap(transposed);
        map.setCyclic(gameState.isCyclicMode());
        return map;
    }
    
    
    private boolean allDotsEaten() {
        for (int x = 0; x < gameState.getWidth(); x++) {
            for (int y = 0; y < gameState.getHeight(); y++) {
                int cell = gameState.getCell(x, y);
                if (cell == GameState.DOT) {
                    return false;
                }
            }
        }
        return true;
    }
    
    @Override
    public void play() {
        if (gameState == null) return;
        if (gameState.getStatus() == PacmanGame.NOT_STARTED || gameState.getStatus() == PacmanGame.PAUSED) {
            gameState.setStatus(PacmanGame.RUNNING);
        } else if (gameState.getStatus() == PacmanGame.RUNNING) {
            gameState.setStatus(PacmanGame.PAUSED);
        }
    }
    
    @Override
    public void end(int code) {
        if (gameState == null) return;
        gameState.setStatus(PacmanGame.DONE);
    }
    
    public GameState getGameState() {
        return gameState;
    }
    
    // GUI and rendering
    private static final double TOP_SPACE = 2.8; // Space at top for score/messages
    private static final double MARGIN = 1.5; // Margin around the map
    private static final double CELL_SIZE = 0.95; // Size of Pacman and normal ghosts (nearly full cell)
    private static final double VULNERABLE_GHOST_SIZE = 0.55; // Smaller size for vulnerable ghosts
    
    private void initializeGUI() {
        if (gameState == null) return;
        int width = gameState.getWidth();
        int height = gameState.getHeight();
        
        // Set canvas size
        StdDraw.setCanvasSize(720, 720);
        
        // Set coordinate system with margins around the map
        // Map area: transposed, so width becomes height and height becomes width
        int displayWidth = height; // Transposed: original height becomes display width
        int displayHeight = width; // Transposed: original width becomes display height
        
        // Balanced scale to show full game
        double extraPadding = 0.8;
        StdDraw.setXscale(-MARGIN - extraPadding, displayWidth + 2*MARGIN + extraPadding);
        StdDraw.setYscale(-MARGIN - extraPadding, displayHeight + TOP_SPACE + MARGIN + extraPadding);
        
        // Enable double buffering for smooth animation
        StdDraw.enableDoubleBuffering();
        
        // Set background to black
        StdDraw.clear(Color.BLACK);
    }
    
    private void render() {
        if (gameState == null) return;
        
        int width = gameState.getWidth();
        int height = gameState.getHeight();
        int displayWidth = height;
        int displayHeight = width;
        
        // Clear with gradient-like dark background
        StdDraw.clear(new Color(10, 10, 30));
        
        // Draw decorative border around the game area
        double borderX = MARGIN - 0.3;
        double borderY = MARGIN - 0.3;
        double borderW = displayWidth + 0.6;
        double borderH = displayHeight + 0.6;
        
        // Outer glow
        StdDraw.setPenColor(new Color(0, 100, 200, 80));
        StdDraw.setPenRadius(0.015);
        StdDraw.rectangle(borderX + borderW/2, borderY + borderH/2, borderW/2 + 0.2, borderH/2 + 0.2);
        
        // Main border
        StdDraw.setPenColor(new Color(0, 150, 255));
        StdDraw.setPenRadius(0.008);
        StdDraw.rectangle(borderX + borderW/2, borderY + borderH/2, borderW/2, borderH/2);
        StdDraw.setPenRadius();
        
        // Draw board transposed (swap x and y for display)
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int cell = gameState.getCell(x, y);
                
                double screenX = y + MARGIN;
                double screenY = x + MARGIN;
                
                if (cell == GameState.WALL) {
                    // 3D-style wall with gradient effect
                    StdDraw.setPenColor(new Color(25, 25, 112)); // Midnight blue base
                    StdDraw.filledSquare(screenX + 0.5, screenY + 0.5, 0.48);
                    
                    // Inner highlight (top-left)
                    StdDraw.setPenColor(new Color(65, 105, 225)); // Royal blue
                    StdDraw.filledSquare(screenX + 0.48, screenY + 0.52, 0.35);
                    
                    // Core
                    StdDraw.setPenColor(new Color(30, 30, 100));
                    StdDraw.filledSquare(screenX + 0.5, screenY + 0.5, 0.30);
                    
                    // Neon edge
                    StdDraw.setPenColor(new Color(100, 149, 237)); // Cornflower blue
                    StdDraw.setPenRadius(0.002);
                    StdDraw.square(screenX + 0.5, screenY + 0.5, 0.47);
                    StdDraw.setPenRadius();
                    
                } else if (cell == GameState.DOT) {
                    // Sparkling dot with soft glow
                    StdDraw.setPenColor(new Color(255, 182, 193, 60)); // Soft pink glow
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.18);
                    StdDraw.setPenColor(new Color(255, 218, 185)); // Peach
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.10);
                    StdDraw.setPenColor(Color.WHITE);
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.05);
                    
                } else if (cell == GameState.POWER_PELLET) {
                    // Glowing power pellet with pulsing effect
                    StdDraw.setPenColor(new Color(50, 255, 50, 40)); // Outer glow
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.42);
                    StdDraw.setPenColor(new Color(0, 255, 100, 80)); // Mid glow
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.35);
                    StdDraw.setPenColor(new Color(50, 255, 50)); // Main green
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.28);
                    StdDraw.setPenColor(new Color(150, 255, 150)); // Inner bright
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.18);
                    StdDraw.setPenColor(new Color(220, 255, 220)); // Center sparkle
                    StdDraw.filledCircle(screenX + 0.5, screenY + 0.5, 0.08);
                }
            }
        }
        
        // Draw Pacman with rotation based on direction (transposed coordinates)
        int pacX = gameState.getPacmanX();
        int pacY = gameState.getPacmanY();
        // Transpose: display at (pacY, pacX)
        double pacScreenX = pacY + MARGIN;
        double pacScreenY = pacX + MARGIN; // Board at bottom, space at top
        double pacRotation = 0.0;
        boolean flipHorizontal = false;
        
        // Calculate rotation/flip based on direction (transposed display)
        // After transposition: RIGHT moves up, LEFT moves down, UP moves right, DOWN moves left
        // Image defaults to facing right
        switch (lastPacmanDirection) {
            case RIGHT:
                pacRotation = 90.0; // RIGHT (dx=1) moves up on screen → rotate 90° to face up
                break;
            case LEFT:
                pacRotation = -90.0; // LEFT (dx=-1) moves down on screen → rotate -90° to face down
                break;
            case UP:
                pacRotation = 0.0; // UP (dy=1) moves right on screen → no rotation (already faces right)
                break;
            case DOWN:
                flipHorizontal = true; // DOWN (dy=-1) moves left on screen → rotate 180° to face left
                pacRotation = 180.0;
                break;
        }
        
        try {
            // Draw Pacman at full cell size with appropriate rotation
            if (flipHorizontal) {
                StdDraw.picture(pacScreenX + 0.5, pacScreenY + 0.5, "resources/p1.png", CELL_SIZE, CELL_SIZE, 180.0);
            } else {
                StdDraw.picture(pacScreenX + 0.5, pacScreenY + 0.5, "resources/p1.png", CELL_SIZE, CELL_SIZE, pacRotation);
            }
        } catch (Exception e) {
            // Fallback: draw Pacman as yellow circle with mouth
            StdDraw.setPenColor(Color.YELLOW);
            StdDraw.filledCircle(pacScreenX + 0.5, pacScreenY + 0.5, CELL_SIZE * 0.45);
        }
        
        // Draw ghosts
        List<GhostImpl> ghosts = gameState.getGhosts();
        String[] ghostImages = {"resources/g0.png", "resources/g1.png", "resources/g2.png", "resources/g3.png"};
        Color[] ghostColors = {Color.RED, Color.PINK, Color.CYAN, Color.ORANGE}; // Classic ghost colors
        
        for (int i = 0; i < ghosts.size() && i < 4; i++) {
            GhostImpl ghost = ghosts.get(i);
            int gX = ghost.getX();
            int gY = ghost.getY();
            // Skip if ghost is off screen (eaten)
            if (gX < 0 || gY < 0) continue;
            
            // Transpose ghost coordinates: display at (gY, gX)
            double ghostScreenX = gY + MARGIN;
            double ghostScreenY = gX + MARGIN;
            
            // Ghost size: full cell when normal, smaller when vulnerable
            double ghostSize = ghost.isVulnerable() ? VULNERABLE_GHOST_SIZE : CELL_SIZE;
            
            try {
                if (ghost.isVulnerable()) {
                    // Draw vulnerable ghost as blue with smaller size
                    StdDraw.picture(ghostScreenX + 0.5, ghostScreenY + 0.5, ghostImages[i], ghostSize, ghostSize);
                    // Add blue tint overlay
                    StdDraw.setPenColor(new Color(0, 0, 255, 100)); // Semi-transparent blue
                    StdDraw.filledCircle(ghostScreenX + 0.5, ghostScreenY + 0.5, ghostSize * 0.4);
                } else {
                    // Normal ghost at full cell size
                    StdDraw.picture(ghostScreenX + 0.5, ghostScreenY + 0.5, ghostImages[i], ghostSize, ghostSize);
                }
            } catch (Exception e) {
                // Fallback: draw ghost as colored circle
                if (ghost.isVulnerable()) {
                    StdDraw.setPenColor(Color.BLUE);
                    StdDraw.filledCircle(ghostScreenX + 0.5, ghostScreenY + 0.5, VULNERABLE_GHOST_SIZE * 0.4);
                } else {
                    StdDraw.setPenColor(ghostColors[i]);
                    StdDraw.filledCircle(ghostScreenX + 0.5, ghostScreenY + 0.5, CELL_SIZE * 0.45);
                }
            }
        }
        
        // Draw score display with decorative styling
        double centerX = displayWidth / 2.0 + MARGIN;
        double topY = displayHeight + MARGIN + TOP_SPACE * 0.65;
        
        // Score background panel
        StdDraw.setPenColor(new Color(20, 20, 60));
        StdDraw.filledRectangle(centerX, topY, 4.5, 0.6);
        StdDraw.setPenColor(new Color(100, 149, 237));
        StdDraw.setPenRadius(0.003);
        StdDraw.rectangle(centerX, topY, 4.5, 0.6);
        StdDraw.setPenRadius();
        
        // Score text with glow effect
        StdDraw.setPenColor(new Color(255, 215, 0)); // Gold
        StdDraw.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 16));
        StdDraw.text(centerX, topY, "SCORE: " + gameState.getScore());
        
        // Draw win/lose message if game is done
        if (gameState.getStatus() == PacmanGame.DONE) {
            double msgY = displayHeight + MARGIN + TOP_SPACE * 0.25;
            
            if (allDotsEaten()) {
                // Victory message with celebration effect
                StdDraw.setPenColor(new Color(50, 255, 50, 60));
                StdDraw.filledRectangle(centerX, msgY, 5.5, 0.8);
                StdDraw.setPenColor(new Color(0, 255, 100));
                StdDraw.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 22));
                StdDraw.text(centerX, msgY, "PACMAN WINS!");
            } else {
                // Game over message
                StdDraw.setPenColor(new Color(255, 50, 50, 60));
                StdDraw.filledRectangle(centerX, msgY, 5.0, 0.8);
                StdDraw.setPenColor(new Color(255, 80, 80));
                StdDraw.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 22));
                StdDraw.text(centerX, msgY, "GAME OVER");
            }
        }
        
        // Show the frame
        StdDraw.show();
    }
}
